import { createApp } from 'vue'
//import App from './App.vue'
//import App from './ex17_store/_3/parentView.vue';
//import store from './ex17_store/_3/store/index.js';

import App from './ex18_component_store/App_1.vue';
import router from './ex18_component_store/router/index2.js';
import store from './ex18_component_store/store/index.js';

//배치할 요소(#app)와 애플리케이션을 연결하는것을 마운트라고 합니다.
//createApp(App).mount('#app')
//createApp(App).use(store).mount('#app')

createApp(App).use(router).use(store).mount('#app')
