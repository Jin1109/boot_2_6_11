<template>
    <!--
        사용자가 입력한 값을 자바스크립트의 데이터로 입력하는 방법입니다.
        태그와 데이터를 연결하기 위해 v-model 디렉티브를 사용합니다.
        웹 페이지에서 입력한 값이 자바스크립트에 반영 되므로 양방향 바인딩이라고도 합니다.
    
        수식어 사용 예
        https://v3.ko.vuejs.org/guide/forms.html#lazy
        1. v-model.lazy
                    입력 후 Enter키나 포커스를 다른 곳으로 이동할 때 name에 입력되어 나타납니다.

        2. v-model.number
        사용자 입력이 자동으로 숫자로 형변환 되기를 원하면, v-model이 관리하는
        input에 number 수식어를 추가하면 됩니다.
        수식으로 변경하고 싶을 때 사용합니다.            
    -->

    <div class="container">
        <input v-model="su1" class="form-control">
        <p> 문자열 연결 : {{su1 + 100}}</p>
        <hr>
        <input v-model.number="su2" class="form-control">
        <p> 입력 즉시 숫자로 연산 : {{su2 + 100}}</p>
        <hr>
        <input v-model.number.lazy="su3" class="form-control">
        <p> 입력 -> 엔터 -> 숫자로 연산 :{{su3 + 100}}</p>
    </div>
</template>

<script>
import {ref, watch} from 'vue';
export default{
    setup(){
        const su1 = ref(0);
        const su2 = ref(0);
        const su3 = ref(0);

        //su1에 변하가 생기면 두 번째 매개변수로 작성한 애로우 함수가 실행됩니다.
        watch(su1, ()=>{
            console.log("su1= " + su1.value);
        })

        //su2에 변하가 생기면 두 번째 매개변수로 작성한 애로우 함수가 실행됩니다.
        watch(su2, () =>{
            console.log("su2= " + su2.value);
        })

        //su1에 변하가 생기면 두 번째 매개변수로 작성한 애로우 함수가 실행됩니다.
        watch(su3, () =>{
            console.log("su3= " + su3.value);
        })

        return{
            su1, su2, su3
        };
        
    }
};
</script>

<style >

</style>