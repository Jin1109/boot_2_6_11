<template>
    <!--
        사용자가 입력한 값을 자바스크립트의 데이터로 입력하는 방법입니다.
        태그와 데이터를 연결하기 위해 v-model 디렉티브를 사용합니다.
        웹 페이지에서 입력한 값이 자바스크립트에 반영 되므로 양방향 바인딩이라고도 합니다.
    -->

    <div class="container">

        <label>과일 <input type="checkbox" v-model="isCheck" value="과일"></label>
        <label>빵 <input type="checkbox" v-model="isCheck" value="빵"></label>
        <label>피자 <input type="checkbox" v-model="isCheck" value="피자"></label>
        <p> 체크 박스의 상태는 {{isCheck}}</p>
    </div>
    <hr>
    <div class="container">
        
        <label>모두 <input type="checkbox" v-model="isAll" value="all" @change="all"></label>
        <label>과일 <input type="checkbox" v-model="isCheck2" value="과일"></label>
        <label>빵 <input type="checkbox" v-model="isCheck2" value="빵"></label>
        <label>피자 <input type="checkbox" v-model="isCheck2" value="피자"></label>
        <p> 체크 박스의 상태는 {{isCheck2}}</p>
    </div>
</template>

<script>
import {ref, watch} from 'vue';
export default{
    setup(){
        const isCheck = ref([]);// 배열을 사용하면 체크한 값이 저장됩니다.
        const isCheck2 = ref([]);
        const isAll = ref(false);//선택하면 true, 해제하면 false값을 갖는다
        const all = () => {
            if(isAll.value){
                isCheck2.value=['과일', '빵', '피자'];
            }else{
                isCheck2.value=[];
            }
        }// all
        
        watch(isCheck2, ()=>{
            isAll.value = isCheck2.value.length==3 ? true : false ;
        }
        
        );
        return{
            isCheck, isCheck2, isAll, all
        };
        
    }
}
</script>

<style >
    label {display: block}
</style>