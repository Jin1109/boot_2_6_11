<template>
  <!--
        사용자가 입력한 값을 자바스크립트의 데이터로 입력하는 방법입니다.
        태그와 데이터를 연결하기 위해 v-model 디렉티브를 사용합니다.
        웹 페이지에서 입력한 값이 자바스크립트에 반영 되므로 양방향 바인딩이라고도 합니다.
    
        동의를 선택하면 전송버튼을 활성화하고
        동의를 선택하지 않으면 전송버튼을 비활성화 합니다.
    -->

    <div class="container">
        <!--
            1. :disabled="true" 이면 disabled 속서을 사용할 수 있습니다.
            :disabled="false" 이면 disabled 속서을 사용할 수 있습니다.
        -->
        <button class="btn btn-info btn-sm" :disabled="false">false</button>
        <button class="btn btn-info btn-sm" :disabled="true">true</button>

     <hr>
        <!--
            2. isCheck가 false이면 disabled 속성을 갖고 isCheck가 ture이면 disabled 속성은 사라집니다.
        -->
     <p>
        <label><input type="checkbox" v-model="isCheck" value='동의'> 동의 합니다: {{isCheck}}</label>
     </p>

     <button class="btn btn-info btn-sm" :disabled="!isCheck">전송</button>

    </div>
        
</template>

<script>
import {ref} from 'vue';
export default {
    setup() {
        const isCheck = ref(false); //true 또는 false
        return {
            isCheck
        };
    }
}
</script>

<style>

</style>