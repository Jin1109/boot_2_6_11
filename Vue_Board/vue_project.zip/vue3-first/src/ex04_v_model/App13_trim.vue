<template>
    <!--
        사용자가 입력한 값을 자바스크립트의 데이터로 입력하는 방법입니다.
        태그와 데이터를 연결하기 위해 v-model 디렉티브를 사용합니다.
        웹 페이지에서 입력한 값이 자바스크립트에 반영 되므로 양방향 바인딩이라고도 합니다.
    
    수식어 사용 예
    3. v-model.trim
                앞뒤 공백을 제거합니다.
    -->

    <div class="container">
        <!-- 입력시 스페이스바를 이용해서 공백을 넣은 후 글자를 입력해 보세요 -->
        <input v-model="name" type="text" class="form-control">
        <p> {{name}} </p>
        <p> {{name.length}} </p>
        <hr>
        <input v-model.trim="name2" type="text" class="form-control">
        <p> {{name2}} </p>
        <p> {{name2.length}} </p>
    </div>
</template>

<script>
import {ref, watch} from 'vue';
export default{
    setup(){
        const name = ref('');
        const name2 = ref('');

        //name에 변하가 생기면 두 번째 매개변수로 작성한 애로우 함수가 실행됩니다.
        watch(name, ()=>{
            console.log(name.value);
        })

        //name2에 변하가 생기면 두 번째 매개변수로 작성한 애로우 함수가 실행됩니다.
        watch(name2, () =>{
            console.log(name2.value);
        })

        return{
            name, name2
        };
        
    }
};
</script>

<style >

</style>