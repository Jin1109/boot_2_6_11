<template>
    <!--
        사용자가 입력한 값을 자바스크립트의 데이터로 입력하는 방법입니다.
        태그와 데이터를 연결하기 위해 v-model 디렉티브를 사용합니다.
        웹 페이지에서 입력한 값이 자바스크립트에 반영 되므로 양방향 바인딩이라고도 합니다.
    -->

    <div class="container">
        <div class="form-group">
            <label for="sell">multiple 옵션을 이용하는 예제</label>
                <select multiple class="form-control" id="sell" v-model="isColor">
                    <option disabled value="" selected>색상을 선택해 주세요</option>
                    <option>red</option>
                    <option>orange</option>
                    <option>yellow</option>
                    <option>blue</option>
                </select>
        </div>

        <p :style="{color:isColor}">나는 {{isColor}} 색 입니다. </p>
    </div>
    
</template>

<script>
import {ref} from 'vue';
export default{
    setup(){
        //multiple 속성을 사용하는 경우 String이 아닌 Array로 초기화합니다.
        const isColor = ref([]); //나는 [ "red", "orange", "yellow", "blue" ] 색 입니다.


        return{
            isColor
        };
        
    }
};
</script>

<style >
    label {display: block}
</style>