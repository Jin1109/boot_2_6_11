<template>
    <!--
        사용자가 입력한 값을 자바스크립트의 데이터로 입력하는 방법입니다.
        태그와 데이터를 연결하기 위해 v-model 디렉티브 사용합니다.
        웹 페이지에서 입력한 값이 자바스크립트에 반영 되므로 양방향 바인딩이라고도 합니다.
    -->
    <div class="container">
        
        <input v-model="name" class="form-control">
        <p> {{name}} </p>

    </div>
</template>

<script>
import {ref, watch} from 'vue';
export default{
    setup(){
        
        const name = ref('');

        //name에 변화가 생기면 두 번째 매개변수로 작성한 애로우 함수가 실행됩니다.
        watch(name, ()=>{
            console.log(name.value);
        })
    
        return{
            name:name
        };
        
    }
}
</script>

<style >

</style>