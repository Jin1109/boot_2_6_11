<template>
  <form name="joinform" > 
   <h1>회원가입 페이지</h1>
   <hr>
   <b>아이디</b>
   <input type="text" v-model="join.id" placeholder="Enter id" required maxLength="12">
   <span :class="id_color">{{id_message}}</span>
   
   <b>비밀번호</b>
   <input type="password" v-model.lazy="join.password" placeholder="Enter password" required>
   
   <b>이름</b>
   <input type="text" v-model.lazy="join.name" placeholder="Enter name" maxLength="15" required>
   
   <b>나이</b> 
   <input type="text" v-model.lazy="join.age" maxLength="2" placeholder="Enter age" 
    pattern="[1-9][0-9]" required>
   
   <b>성별</b>
   <div>
      <input type="radio" v-model.lazy="join.gender" value="남"><span>남자</span>
      <input type="radio" v-model.lazy="join.gender" value="여"><span>여자</span>
   </div>
   
   <b>이메일 주소</b>
   <input type="text" v-model="join.email" placeholder="Enter email" required>
   <span id="email_color">{{email_message}}</span>

      <div class="clearfix">
         <button type="submit" class="submitbtn">회원가입</button>
         <button type="reset" class="cancelbtn">다시작성</button>
      </div>

</form>
</template>

<script>
import {ref, watch} from 'vue';
export default {
    setup() {
        const join = ref({
            id:'admin', 
            password:'1234',
            name: '관리자',
            age:21,
            gender:'여',
            email:'admin@hta.co.kr'
   });
   const id_message = ref('');
   const email_message = ref('');
   const id_color = ref('');
   const email_color = ref('');

watch(join.value,()=>{
    console.log("[===============]");
    console.log(join.value.id);
    console.log(join.value.password);
    console.log(join.value.name);
    console.log(join.value.age);
    console.log(join.value.gender);
    console.log(join.value.email);
    console.log("[===============]");
})
    return{
            join, id_message, email_message, id_color, email_color
        };
    }
}
</script>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}

input{border-radius:3px;border:1px solid lightgray}
input[type=text], input[type=password] {
    width: 100%;
    padding: 10px;
    margin: 5px 0 22px 0;
    display: inline-block;
}

input[type=radio]{
	width: 5%;
    display: inline-block;
    border: none;
}

input[type=text]:focus, input[type=password]:focus {
  box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
    outline: none;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    width: 100%;
    opacity: 0.8;
}

button:hover {
    opacity:1;
     cursor: pointer; /* �հ��� Ŀ�� ��� */
    
}
button:focus{
   outline:none;
}

/* ��� ��ư*/
.cancelbtn {
    padding: 14px 20px;
    background-color: #f44336;
}

.cancelbtn, .submitbtn {
  float: left;
  width: 50%;
}

form {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid lightgray;
    width: 600px; /* Could be more or less, depending on screen size */
    padding: 16px;
}

hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}
 
b + div{width: 100%;
    padding: 10px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;}

/* Clear floats */
.clearfix::after {
    content: "";
    clear: both;
    display: table; 
}

h1{text-align:center}

b {
	width: 100%;
	display: block
}

span{display:inline-block;margin-top:-20px;font-size:10px}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
    .cancelbtn, .signupbtn {
       width: 100%;
    }
}
</style>