<template>
    <!--
        사용자가 입력한 값을 자바스크립트의 데이터로 입력하는 방법입니다.
        태그와 데이터를 연결하기 위해 v-model 디렉티브를 사용합니다.
        웹 페이지에서 입력한 값이 자바스크립트에 반영 되므로 양방향 바인딩이라고도 합니다.
    -->

    <div class="container">
        <div><label><input type="radio" v-model="isColor" value='red'>빨간색</label></div>
        <div><label><input type="radio" v-model="isColor" value='yellow'>노란색</label></div>
        <div><label><input type="radio" v-model="isColor" value='orange'>오렌지색</label></div>
        <p> value : {{ isColor }}</p>
        <p :style="{color:isColor}">나는 {{isColor}} 색 입니다. </p>

        <hr>
        isColor2의 초기값을 주면 해당 radio 버튼이 선택됩니다.
        <div><label><input type="radio" v-model="isColor2" value='red'>빨간색</label></div>
        <div><label><input type="radio" v-model="isColor2" value='yellow'>노란색</label></div>
        <div><label><input type="radio" v-model="isColor2" value='orange'>오렌지색</label></div>
    </div>
</template>

<script>
import {ref} from 'vue';
export default {
    setup() {
        const isColor = ref(''); //String으로 초기화 합니다.
        const isColor2 = ref('red'); //초기값으로 'red'를 주며 빨간색 선택됩니다.
        return {
            isColor, isColor2
        };
    }
}
</script>

<style>

</style>