<template>
    <!--
        사용자가 입력한 값을 자바스크립트의 데이터로 입력하느 방법입니다.
        태그와 데이터를 연결하기 위해 v-model 디렉티브를 사용합니다.
        웹 페이지에서 입력한 값이 자바스크립트에 반영 되므로 양방향 바인딩이라고도 합니다.

        영문을 사용하면 입력한 만큼 글자의 수가 표시되지만 한글은 다음 글자를 입력해야
        입력한 글자수가 카운트됩니다.
        
        IME는 한글, 한자처럼 컴퓨터 자판에 있는 글쇠보다 수가 더 많은 문자를 계산하거나
        조합하여 입력해 주는 시스템 스프트웨어입니다.

        https://v3.ko.vue.js.org/guide/forms.html#기존-사용법
        공식문서에
        IME가 필요한 언어(중국어, 일본어, 한국어)등의 경우 IME 구성 중에 v-model이 
        업데이트가 되지 않을 수 있으므로 input 이벤트를 사용하려고 나와 있습니다.
    -->

    <div class="container">
        <textarea v-model="statement" class="form-control" maxlength="10"></textarea>
        <p>입력 : {{statement}}</p>
        <p>입력한 글자수는  {{statement.length}}개 입니다.</p>
    </div>
</template>

<script>
import {ref, watch} from 'vue';
export default{
    setup(){
        const statement = ref('');
    
        return{
            statement
        };
        
    }
}
</script>

<style >

</style>