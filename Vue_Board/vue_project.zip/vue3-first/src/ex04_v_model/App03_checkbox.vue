<template>

    <div class="container">
        <h5 class="orange">
            체크박스가 선택하면 true, 해제시 false 값을 갖지만 프로퍼티가 배열인 경우 값을 저장합니다.
        </h5>

        <hr>
        <h6 class="green"> 프로퍼티 값이 true 또는 false인 경우 </h6>
        <label>vue <input type="checkbox" v-model="isCheck" value="one"></label>
        <p> 체크 박스의 상태는 {{isCheck}}</p>

        <hr>
        <h6 class="green"> 프로퍼티가 배열인 경우 </h6>
            <label>vue <input type="checkbox" v-model="selectedValue" value="vue.js"></label>
            <label>html <input type="checkbox" v-model="selectedValue" value="HTML"></label>
        <p> 선택한 체크 박스의 값은 {{selectedValue}}</p>
    </div>
</template>

<script>
import {ref} from 'vue';
export default{
    setup(){
        const isCheck = ref(false);//초기값으로 false를 주면 해제가 되고 체크하면 true값을 반환
        const selectedValue = ref([]);//초기값으로 배열을 사용한 경우 체크한 값을 배열에 저장

        return{
            isCheck, selectedValue
        };
        
    }
}
</script>

<style >
    label {display: block}
    .green{color:green; font-weight: 900;}
    .orange{color:orange}
</style>