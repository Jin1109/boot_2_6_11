<template>
    <!--
        사용자가 입력한 값을 자바스크립트의 데이터로 입력하는 방법입니다.
        태그와 데이터를 연결하기 위해 v-model 디렉티브를 사용합니다.
        웹 페이지에서 입력한 값이 자바스크립트에 반영 되므로 양방향 바인딩이라고도 합니다.
    -->

    <div class="container">
        <div class="from-group">
          <label>Select list:</label>
            <select class="form-control" v-model="isColor">
              <option disabled value="" selected>색상을 선택해 주세요 </option>
              <option>red</option>
              <option>orange</option>
              <option>yellow</option>
              <option>blue</option>
            </select>     
    </div>

    <p :style="{color:isColor}">나는 {{isColor}} 색 입니다. </p>
    <hr>

        <div class="form-group">
        <label>orange를 선택하도록 isColor2에 초기값을 줍니다.</label>
        <select class="form-control" v-model="isColor2">
            <option disabled value="" selected>색상을 선택해 주세요 </option>
            <option>red</option>
            <option>orange</option>
            <option>yellow</option>
            <option>blue</option>
        </select>
        </div>
    </div>             
</template>

<script>
import {ref} from 'vue';
export default {
    setup() {
        const isColor = ref(''); //나는 red 색 입니다.
        const isColor2 = ref('orange'); //'orange'색이 선택됩니다.
        return {
            isColor, isColor2
        };
    }
}
</script>

<style>

</style>