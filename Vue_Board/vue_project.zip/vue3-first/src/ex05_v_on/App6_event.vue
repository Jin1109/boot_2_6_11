<template>
    <!--
        1. 이벤트와 함수를 연결하는 v-on입니다.
        2. focus 이벤트
    -->

    <div class="container">
        <!-- input 엘리먼트에 클릭한 경우 clear 실행됩니다. 
            매개변수가 있는 경우 event객체를 사용하기 위해 특수 $event 변수를 사용하여
            메서드에 전달할 수 있습니다.
        -->
        <input v-on:focus="clear('vue', $event)" value="나를 클릭해서 매개변수의 값으로 변경해주세요"
                class="form-control">
    </div>
</template>

<script>
export default{
    setup(){
        
        const clear = (message, event)=>{
            console.log(`넘어온 값 : ${message}`);
            console.log(`value 속성 값 : ${event.target.value}`);
            console.log(`태그 이름 : ${event.target.tagName}`);
            //event.target.value='';//이벤트가 발생한 객체의 값을 초기화 입니다.
            event.target.value=message;
        }

        return{
            clear
        };      
    }
};
</script>

<style >
 
</style>