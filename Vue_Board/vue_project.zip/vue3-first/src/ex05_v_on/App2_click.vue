<template>
<!--
    1. 이벤트와 함수를 연결하는 v-on입니다.
    2. 형식)
        <태그명 v-on:이벤트="함수">
        <태그명 @이벤트="함수">
-->

    <div class="container">
        <p>{{ count }}</p>
        <button v-on:click="count++" class="btn btn-warning">값 증가</button>
    </div>
</template>

<script>
import {ref} from 'vue';
export default{
    setup(){
        const count = ref(0);

        return{
            count
        };      
    }
};
</script>

<style >
 
</style>