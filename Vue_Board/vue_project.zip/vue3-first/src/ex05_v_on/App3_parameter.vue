<template>
<!--
    * 이벤트와 함수를 연결하는 v-on입니다.
        매개변수가 있는 함수와 연결합니다.    
-->

    <div class="container">
        <p>{{count}}</p>
        <button v-on:click="add(10)" class="btn btn-warning">값 증가</button>
    </div>
</template>

<script>
import {ref} from 'vue';
export default{
    setup(){
        const count = ref(0);

        const add = (increment) => {
            count.value += increment;
        }
    
        return{
            count, add
        };      
    }
};
</script>


<style >
 
</style>