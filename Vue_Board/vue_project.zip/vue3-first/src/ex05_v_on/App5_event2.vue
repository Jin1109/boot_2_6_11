<template>
<!--
    * 1. 이벤트와 함수를 연결하는 v-on입니다.
      2. focus 이벤트
-->

    <div class="container mt-3">
        <input v-on:focus="clear(10)" value="나를 클릭히세요" class="form-control">

        <input v-on:focus="clear()" value="나를 클릭하세요" class="form-control">
    </div>
</template>

<script>
export default {
    setup() {
    /*기본값 함수 매개변수 (default function parameter)를 사용하면 값이 없거나
      underfined가 전달될 경우 이름붙은 매개변수를 기본값으로 초기화할 수 있습니다. */
        const clear = (data=20) =>{
            console.log('focus')
            console.log(data)
        };
    
        return{
            clear
        };      
    }
};
</script>


<style >
 
</style>