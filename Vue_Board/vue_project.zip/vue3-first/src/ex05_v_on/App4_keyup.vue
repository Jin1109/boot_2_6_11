<template>
<!--
    * 1. 이벤트와 함수를 연결하는 v-on입니다.
      2. keyup 이벤트를 수식어와 함꼐 함수를 연결합니다.
         v-on:keyup.enter : enter를 눌렸을 떄 이벤트 실행
         v-on:keyup.tab : tab를 눌렸을 떄 이벤트 실행
-->

    <div class="container">
        <input v-on:keyup.enter="message" >
    </div>
</template>

<script>
export default {
    setup() {

        const message = () =>{
            alert('Enter를 눌렸습니다.');
        };
    
        return{
            message
        };      
    }
};
</script>


<style >
 
</style>