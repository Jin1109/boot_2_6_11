<template>
<!--
    * 1. 이벤트와 함수를 연결하는 v-on입니다.
      2. focus 이벤트
-->

    <div class="container mt-3">
        <!-- input 엘리먼트에 포커스를 준 경우 clear 실행돕니다. -->
        <input v-on:focus="clear" value="나를 클릭해서 클리어 해주세요" class="form-control">
    </div>
</template>

<script>
export default {
    setup() {

        const clear = (event) =>{
            console.log('focus')
            event.target.value=''
        };
    
        return{
            clear
        };      
    }
};
</script>


<style >
 
</style>