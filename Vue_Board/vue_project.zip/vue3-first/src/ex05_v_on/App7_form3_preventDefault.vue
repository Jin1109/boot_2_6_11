<template>
    <!--
        1. 이벤트와 함수를 연결하는 v-on입니다.
        2. focus 이벤트
        3. Submit 버튼을 클릭하면 새로고침 됩니다. 즉, 페이지 이동한 것입니다.
            페이지 이동을 막도록 해보겠습니다.
    -->

    <div class="container">
        <form @submit.prevent="go">
            <input v-on:focus="clear('vue', $event)" value="나를 클릭해서 클리어 해주세요" class="form-control"> <br>
            <button type="submit" class="btn btn-primary" >Submit</button>
        </form>

    </div>
</template>

<script>
export default{
    setup(){
        
        const clear = (message, event)=>{
            console.log(`넘어온 값 : ${message}`);
            console.log(`value 속성 값 : ${event.target.value}`);
            console.log(`태그 이름 : ${event.target.tagName}`);
            event.target.value='';//이벤트가 발생한 객체의 값을 초기화 합니다.
        };

        const go= (event)=>{
            event.preventDefault();
            alert('이동할 수 없습니다2.');
            console.log(`(go)태그 이름 : ${event.target.tagName}`)
        }

        return{
            clear,go
        };      
    }
};
</script>

<style >
 
</style>