<template>
<!--
    1. 이벤트와 함수를 연결하는 v-on입니다.
    2. 형식)
        <태그명 v-on:이벤트="함수">
        <태그명 @이벤트="함수">
-->

    <div class="container">
        <p class='white'>버튼을 클릭하면 값이 1씩 증가합니다. => {{count}}</p>
        <button class="btn btn-warning" v-on:click="add">값 증가</button>
    </div>
</template>

<script>
import {ref} from 'vue';
export default{
    setup(){
        const count = ref(0);

        const add = () => {
            count.value++;
        }
    
        return{
            count, add
        };      
    }
};
</script>

<style >
 
</style>