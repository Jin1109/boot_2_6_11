<template>

    <div class="container">
        <div class="from-group mt-3">
            <select clas="form-control" v-model="field">
                <option value="name">이름</option>
                <option value="age">나이</option>
            </select>

            <input
             type="search"
             placeholder="검색어 입력 후 Enter"
             v-model.lazy.trim="search_word"
             class="form-control"
             >    
        </div>


    <table class="table table-stripped" v-show="show_list.length>0">
        <caption>
            <h3>name list</h3> 
        </caption>
        <tbody>
            <tr>
                <th>번호</th>       
                <th>이름</th>       
                <th>나이</th>
            </tr>

            <tr v-for="(item, index) in show_list" :key="index">
                <td>{{index + 1}}</td>
                <td>{{item.name}}</td>
                <td>{{item.age}}</td>
            </tr>
        </tbody>
    </table>
    <div v-show="show_list.length==0"> 데이터가 존재하지 않습니다.</div>
    </div>                      
</template>

<script>
import {computed, ref} from 'vue'
export default{
    setup(){
        //원본 데이터를 갖고 있는 배열
        const name_list = [
            { name : "홍길동", age : 20},
            { name : "이순신", age : 30},
            { name : "신사임당", age : 40},
            { name : "추가", age : 40}
        ];

        const search_word = ref('');
        const field = ref('name');
            

        const show_list =computed(()=>{
            //검색어가 없는 상태에서는 모든 데이터가 나타나도록 합니다.
            if(search_word.value==''){
                return name_list;
            }
            return name_list.filter(el => {
                if(field.value=='name'){
                    return el.name.includes(search_word.value);
                }
                return el.age == search_word.value;
            });
        });

        return{
            show_list, search_word, field
        };
    }
};
</script>

<style>
    caption {
        caption-side: top;
        text-align: center;
    }
    table {
        text-align: center;
    }
    .form-control{
        display: inline-block;  
        width: inherit;
    }

    .form-group{
        text-align: center
    }

    button{
        vertical-align:top
    }
</style>