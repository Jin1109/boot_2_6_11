<template>
  <!--
    https://v3.ko.vuejs.org/guide/reactivity-computed-watchers.html
    1. 계산된 속성(computed properties) 이란 미리 연산한 값을 갖고 있는 것을 의미합니다.
    2. 계산된 속성(computed properties) 사용 방법
        형식)
        const sum = computed(()=>{
                  return 리턴값;
        })
  -->

  <div class="container">
    <h5> 반지름을 입력하면 넓이를 계산합니다. </h5>
    <h2> 반응형 데이터 radius의 값이 변경되면 계산된 속성 변경</h2>
    <label> 반지름(m) <input type="text" v-model.number="radius" class="form-control"></label>
    <p>넓이 : {{ getArea}} m<sup>2</sup></p>
    <p>원의 둘레 : {{ getCir }} m</p>
    </div>   
</template>

<script>
import {ref, computed} from 'vue';
export default {
    setup() {
        const radius = ref(0);
        const PI = 3.141592;
        const getArea = computed(()=>{
              return radius.value * radius.value * PI;
        });

        const getCir = computed(()=>
                2 * radius.value * PI   //중괄호 없이 문장 한개만 작성하는 경우 세미콜론을 사용하지 않습니다.
                                        //이 경우sms 2 * radiues.value * PI 계산된 결과값을 return 합니다.
        );

        return {
            radius, getArea, getCir
        }
    }

}
</script>

<style>

</style>