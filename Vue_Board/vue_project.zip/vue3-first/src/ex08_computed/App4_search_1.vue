<template>
  
    <div class="container">

    </div>    
</template>

<script>
import {computed, ref} from 'vue'
export default{
    setup(){
        //원본 데이터를 갖고 있는 배열
        const name_list = [
            { name : "홍길동", age : 20},
            { name : "이순신", age : 30},
            { name : "신사임당", age : 40},
            { name : "추가", age : 40},

        ];

        //includes() 메서드는 하나의 문자열이 다른 문자열에 포함되어 있는지를 판별하고, 결과를 true 또는 false로 반환합니다.
        //name_list[0]의 객체 속성 name의 값에 '이'가 포함되었는지 판별합니다.
        console.log(name_list[0].name.includes('이'));

        //배열의 filter()는 모든 요소에 대해 매개변수로 작성한 함수의 조건에 맞는 모든 요소를 모아
        //새로운 배열로 변환합니다.
        const result = name_list.filter(el =>{
            return el.age == 40;
        });

        console.log(result);
    
    }
};
</script>

<style>

</style>