<template>
    <div class="container">
        <!-- 한글 갯수 처리하기 위해 input 이벤트 작성. -->
        <h3>후기를 남겨 주세요({{max}}자 이내) </h3>
        <textarea
        :value="view"
        :maxlength="max"
        v-on:input="update"
        class="form-control"
        v-bind:style="{color:computedColor}"
        ></textarea>
        <p>남은 글자는 <span v-bind:style="{color:computedColor}">{{remaining}}</span> / {{max}}입니다.</p>
    </div>
</template>

<script>
import {computed, ref} from 'vue'
export default{
    setup(){
        const view = ref('');
        const max=ref(50);
        const update = (event)=>{
            view.value=event.target.value;
            if(view.value.length>max.value){ //한글의 경우 -1까지 표시 되어 처리
              view.value-view.value.substring(0,max.value);
            }
        }
        const remaining = computed(()=>{
            return max.value-view.value.length;
        });

        const computedColor = computed(()=>{
            if(remaining.value<10){
                return 'red';
            }
            return 'green';
        });

        return{
            view, remaining, computedColor, max, update
        };      
    }
};
</script>

<style scoped>

</style>

