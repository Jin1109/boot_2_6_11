<template>
    <!--
        https://v3.ko.vuejs.org/guide/computed.html#computed-속성의-캐싱-vs-메서드
        1. computed 속성은 반응형(reactive) 종속성에 기반하여 캐시됩니다.
        2. computed 속성은 반응형 종속성 중 일부가 변경된 경우에만 재평가됩니다
        3. 예로 계산된 속성(computed properties)이 사용하는
            Math.random()은 리액티브 데이터가 아니므로 몇 번을 실행해도 같은 숫자가 리턴됩니다.
    -->
    <div class="container">    
        <ul>
            <li>{{computedData}}</li>
        </ul>

        <ul>
            <li>{{computedData}}</li>
        </ul>

        <ul>
            <li>{{methodsData()}}</li> <!-- 함수를 실행합니다. -->
        </ul>

        <ul>
            <li>{{methodsData()}}</li> <!-- 함수를 실행합니다. -->
        </ul>
    </div>
</template>

<script>
import {computed} from 'vue'
export default{
    setup(){
        
        const methodsData = ()=>{
            return Math.random();
        }

        const computedData = computed(()=>{
            return Math.random();
        })

        return{
            computedData, methodsData
        };      
    }
};
</script>

<style scoped>

</style>

