<template>
<!-- {{}} 안에 사용된 val이 부모로 부터 받은 속성임을 props 속성에서 명시해야 합니다. -->
  <div class="child">부모 컴포넌트에서 받은 값  : {{val}}</div>
</template>
<!--
https://v3.ko.vuejs.org/guide/component-props.html#prop-타입
https://v3.ko.vuejs.org/guide/component-props.html#prop-유효성-검사
컴포넌트는 prop에 대한 요구 사항을 지정할 수 있고 요구사항이
충족되지 않으면 브라우저의 자바스크립트 콘솔에서 경고합니다.
-->
<script>
export default {
  props:{
    //문자열로 필수
    val:{
      type:String,
      required:true
    }
  }
}
</script>

<style scoped>
  .child{background-color: azure;}
</style>\