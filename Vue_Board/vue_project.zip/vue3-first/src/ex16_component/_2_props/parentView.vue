<template>
  <div class="parent">
    나는 부모입니다.
    <!-- 정적 속성 val의 값을 자식에게 전달합니다.-->
    <child val="나는 부모"/>

    <!-- 속성 val을 전달하지 않습니다. child 컴포넌트에서 val의 required:ture로 설정했기 때문에 오류 발생합니다.-->
    <child/>
  </div>  
</template>

<script>
/*  https://kr.vuejs.org/v2/guide/components.html
    1. 컴포넌트란
    조합하여 화면을 구성할 수 있는 블록을 의미합니다.
    컴포넌트를 활용하면 화면을 빠르게 구조화하여 일괄적인 패턴으로 개발 할 수 있으며,
    코드를 쉽게 이해하고 재사용 할 수 있습니다.

    2. 컴포넌트 사용법
       (1) <script>에서 컴포넌트의 위치와 이름을 import문으로 작성합니다.
       (2) export default { 의 components 속성에 사용할 컴포넌트 이름을 작성합니다.
       (3) <template>에서 컴포넌트를 배치합니다.

*/
import child from './childView.vue'
export default {
    components:{
        child
    }
}
</script>

<style scoped>
 .parent{
    background-color: cornsilk;
 }
</style>