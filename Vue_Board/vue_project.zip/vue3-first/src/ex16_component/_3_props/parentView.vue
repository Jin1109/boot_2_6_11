<template>
  <div class="parent">
    나는 부모입니다.
    <!-- 데이터 바인딩이 아닌 경우 "message"는 문자열입니다.-->
    <child val="message"/>

    <!-- 동적 속성을 전달하기 위한 콜론(:)을 사용합니다.
         여기서 사용된 message는 자바스크립트의 속성 입니다.
         데이터 바인딩합니다. -->
    <child :val="message"/>

    <input v-model="message"><!-- 부모 컴포넌트에서 입력한 값이 자식 컴포넌트에 적용됩니다. -->
  </div>
</template>

<script>

import child from './childView.vue';
import {ref} from 'vue'
export default {
  components:{
    child
  },
  setup(){
    const message=ref('초기값');
    return{
      message
    }
  }
}
</script>

<style scoped>
  .parent{
    background-color: cornsilk;
  }
</style>