<template>
<!-- {{}} 안에 사용된 val이 부모로 부터 받은 속성임을 props 속성에서 명시해야 합니다. -->
  <div class="child">부모 컴포넌트에서 받은 값  : {{val}}<br>
  부모에게 넘길 값 : <input @input="change">
  </div>
</template>

<script>
export default {
  props:{
    val:{
      type:String,
      required:true
    }
  },
  emits:['parent_message'],
  setup(props, context){
    //setup()의 첫번째 매개변수 props를 이용하면 props에 명시한 속성값을 알 수 있습니다.
       console.log(`props.val = ${props.val}`);

       const change = (event)=>{
       /*
             자식 컴포넌트에서 부모 컴포넌트로 데이터를 전달할 때 이 방식을 사용합니다.
             자식은 context.emit('parent_message', send_message.value); 처럼
             context.emit()메서드를 호출하면 됩니다.
             첫번째 인자는 부모에서 정의한 이벤트 이름,
             두번째 인자는 부모 에게 보낸 값 입니다.
        */
        context.emit('parent_message', event.target.value);     
       }
       return{
        change
       }
  }
}
</script>

<style scoped>
  .child{background-color: azure;}
</style>\