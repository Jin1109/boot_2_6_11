<template>
  <div class="parent">
    <!-- 1. :val="message"
            동적 속성을 전달하기 위한 콜론(:)을 사용합니다.
            여기서 사용된 message는 자바스크립트의 속성입니다.
            데이터 바인딩합니다.
        
         2. @parent_message="getMessage"
           parent_message : 사용자 정의 이벤트 이름
           getMEssage : 이벤트를 실행할 함수
           자식 컴포넌트에서 부모 컴포넌트로 데이터를 전달할 때 이 방식을 사용합니다.
           자식은 context.emit('parent_message', send_message.value);처럼
           context.emit()메서드를 호출하면 됩니다.
           첫번째 인자는 부모에서 정의한 이벤트 이름,
           두번째 인자는 부모에게 보낼 값 입니다.
    -->
    <child :val="message" @parent_message="getMessage"/>


    <div> 여기는 부모 : 자식에게 받은 값을 출력하는 곳 <br>
    <span>{{showMessage}}</span></div>
  </div>
</template>

<script>
import child from './childView.vue';
import {ref} from 'vue'
export default {
    components:{
      child
    },
    setup(){
      const message=ref('초기값');
      const showMessage = ref('');

      //자식 컴포넌트에서 context.emit('parent_message', send_message.value); 로 보낸 두 번째 읹가
      // value에 전달됩니다.
      const getMessage = (value)=>{
        console.log(value);
        showMessage.value=value;
      }
      return {
        message, getMessage, showMessage
      }
    }
}
</script>

<style scoped>
  .parent{
    background-color: cornsilk;
  }
</style>