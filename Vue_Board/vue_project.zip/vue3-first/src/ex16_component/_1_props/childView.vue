<template>
  <div class="child">부모 컴포넌트에서 받은 값 : {{val}}</div>
</template>

<script>
//F12 오류 확인 - {{val}}의 val에 대한 정의가 없어 오류 발생합니다.
export default {

}
</script>

<style>
.child{background-color: azure;}
</style>