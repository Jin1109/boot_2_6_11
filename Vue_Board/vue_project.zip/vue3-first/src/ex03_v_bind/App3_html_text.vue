<template>
    <!--
        v-html : 자바스크립트의 속성값 문자열을 html로 인식합니다.
        v-text : 자바스크립트의 속성값을 문자열로 인식합니다.
    -->
    <div class="container">
        <p v-html="scriptdata"></p>
        <p v-text="scriptdata"></p>
    </div>
</template>

<script>
import {ref} from 'vue';
export default{
    setup(){
        
        const scriptdata = ref('<a href="http://www.naver.com">naver</a>');
    
        return{
            scriptdata
        }
    }
}
</script>

<style >

</style>