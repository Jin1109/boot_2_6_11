<template>
    <!--
        1. v-로 시작하는 속성은 디렉티브라고 하며 주로 단방향 데이터 바인딩과 관련된 처리를 실시합니다.
            중요한 것은 디렉티브의 값이 자바스크립트에서 리턴한 프로퍼티를 사용합니다.
        
        2. 다음은 태그의 속성을 데이터로 지정하고 싶을 때 사용하는 v-bind 입니다.
            형식)
                (1) <태그명 v-bind:태그속성="프로퍼티명"></태그명>
                (2) <태그명 :태그속성="프로퍼티명"></태그명>
        
            예)
                (1) <p v-bind:class="프로퍼티명">
                (2) <p :class="프로퍼티명">

        3. 클래스 속성 지정 방법
            (1) <p :class='프로퍼티명'>
            (2) <p :class='[프로퍼티명, 프로퍼티명, ..]'>
            (3) <p :class='{클래스명 : 프로퍼티명의 값이 true 또는 false}'>
    -->
    <div class="container">
        <p class='white'>클래스 속성</p>
        
        <!-- 결과 소스
            <p class="white">바인드로 지정</p>
        -->
        <p :class='myClass'>바인드로 지정</p>

        <!-- 클래스를 여러 개 지정할 경우 배열형식으로 지정합니다.
             결과 소스 
             <p class="white cancel">바인드로 지정 - 여러 개 클래스 지정</p> -->
        <p :class='[myClass, myCancel]'>바인드로 지정 - 여러 개 클래스 지정은 배열이용</p>
    </div>
</template>

<script>
//자바스크립트 영역입니다.
export default{
    setup(){
        const myClass = 'white';
        const myCancel = 'cancel';
    
        return{
            myClass, myCancel
        }
        
    }
}
</script>

<style >
    .white{
        color:white;
        font-size: 20px;
        background-color: black;
    }

    .cancel{
        text-decoration: line-through;
    }
    
</style>