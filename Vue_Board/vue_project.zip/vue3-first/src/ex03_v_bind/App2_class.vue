<template>
    <!--
                예)
                    (1) <p v-bind:class="프로퍼티명">
                    (2) v-bind: => "로 간단히 사용 가능합니다.
                        <p :class="프로퍼티명">
    -->
    <div class="container">
        
        <p :class="{'cancel': isTrue}"> isTrue가 참이면 클래스 cancel이 적용됩니다.</p>

        <p :class="{'cancel': isFalse}"> isFalse가 거짓이면 클래스 cancel이 적용되지 않습니다.</p>

    </div>
</template>

<script>
export default{
    setup(){
        const isTrue = true;
        const isFalse = false;
    
        return{
            isTrue, isFalse
        }
        
    }
}
</script>

<style >
    .cancel{
        text-decoration: line-through;
    }
    
</style>