<template>
    <!--
        1. v-로 시작하는 속성은 디렉티브라고 하며 주로 단방향 데이터 바인딩과 관련된 처리를 실시합니다.
            중요한 것은 디렉티브의 값이 자바스크립트에서 리턴한 프로퍼티를 사용합니다.
        
        2. 태그의 속성을 데이터로 지정하고 싶을 때 사용하는 v-bind 입니다.
            형식)
                (1) <태그명 v-bind:태그속성="프로퍼티명"></태그명>
                (2) <태그명 :태그속성="프로퍼티명"></태그명>

        3. 속성 style 바인딩
            (1) 프로퍼티가 객체인 경우
                형식) <li :style="프로퍼티명">
                사용예) <li :style="color_style">

            (2) 프로퍼티가 스트링인 경우
                형식) <li :style="{style속성 : 프로퍼티명}">
                사용예) :style="{color: colorChange}">
    -->
    <div class="container">
        
        <ol>
            <li style="color: red;"> 인라인 스타일 지정 방법 : style="color:red" </li>
            <li :style="color_style"> :style="color_style" </li>
            <li :style="{color: colorChange}"> :style="{color: colorChange }" </li>
        </ol>

    </div>
</template>

<script>
export default{
    setup(){
        
        //케밥 표기법 - HTML,CSS에서 복수 단어 사이를 하이픈(-)으로 연결해서 사용하는 방식
        //const color_style = {'color': 'orange', 'font-size':'30px'};

        //카멜 표기법 - 복수 단어 사이의 하이픈을 없애고 두 번째 이후 단어의 시작은 대문자로 표기하는 방식
        const color_style = {color: 'orange', fontSize:'30px'};

        const color=prompt('바꿀 색상을 입력하세요','blue');
    
        return{
            color_style,
            colorChange : color
        }
        
    }
}
</script>

<style >

</style>