<template>
<!-- session에 값이 있는 경우 : 메뉴바 생성 확인합니다. -->      
  <nav class="navbar navbar-expand-sm right-block navbar-dark" v-if="id">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="logout">{{id}}님(로그아웃)</a>
      </li>
      <li class="nav-item">
        <router-link class="nav-link" :to="{name:'Update'}">정보수정</router-link></li>

      <!-- admin 메뉴 -->
      <div v-if="id=='admin'">
        <!-- Dropdown -->
        <li class="nav-item dropdown"><router-link
            class="nav-link dropdown-toggle" to="#" id="navbardrop"
            data-toggle="dropdown"
            > 관리자 </router-link>
            <div class="dropdown-menu" >
            <!-- to="{name:'Info'}" route의 이름으로 접근하는 방식 -->
              <router-link class="dropdown-item" :to="{name:'Info'}">회원정보</router-link>
              <router-link class="dropdown-item" :to="{name:'Board'}">게시판</router-link>
            </div></li>
      </div>
    </ul>
  </nav>

<div class="container">
  <router-view/>
</div>
</template>

<script>
import axios from './axios/axiossetting.js'
import {ref } from 'vue';
export default {
    setup(){
        const id = ref('');
        const getSession = async()=>{
            try{
                //const res = await axios.get("getSession_ex");//res=admin
                const res = await axios.get("getSession_ex"); //res= <nav>나타나지 않습니다.
                console.log("res="+res.data)
                id.value=res.data;
                if(id.value==''){ //null은 값으론 빈문자열로 리턴
                  console.log('null');
                }
            }catch(err){
                console.log(err);
            }
        }

        getSession();

        return{
          id
        }
    }
}
</script>

<style scoped>
   nav.navbar {
   justify-content: flex-end; /* 오른쪽 정렬 */
}

.dropdown-menu {
min-width: 0rem; 
}

/* nav 색상 지정 */
.navbar {
   background: #096988;
   margin-bottom: 3em;
   padding-right: 3em;
}

.navbar-dark .navbar-nav .nav-link {
   color: rgb(255, 255, 255);
}

.dropdown-menu a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-menu {
  display: block;
}

</style>