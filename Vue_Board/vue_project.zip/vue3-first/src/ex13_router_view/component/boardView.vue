<template>
  <div>
    이곳은 게시판 페이지 입니다.
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>