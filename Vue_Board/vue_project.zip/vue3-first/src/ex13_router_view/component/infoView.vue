<template>
  <div>
    이곳은 회원정보 페이지 입니다.
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>