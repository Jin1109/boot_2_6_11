<template>
    <div class='container'>
        <div>
            객체로 표현 : {{name}}
        </div>
        <div>
            객체의 타이틀 출력 : {{name.title}}
        </div>    
        <button class="btn btn-primary" @click="consoleLog">이름 변경</button>
    </div>
</template>

<script>
/*
    1. 버튼을 클릭하면 콘솔에 홍길동이 출력 되고 template의 {{name}}도 변화됩니다.
    2. 버튼을 클릭하면 값도 반응형 데이터가 될 수 있도록 변경하기 위해 아래와 같이 함수를 import
*/
import {ref} from 'vue';
export default{
    setup(){
        
        const name = ref({title : 'vue'});
        const consoleLog=()=>{
            name.value.title='홍길동';
            console.log(name.value.title); //ref()를 사용하면 속성 value로 값에 접근합니다.
        }

        return{
            name : name,
            consoleLog : consoleLog
        }
    }
}
</script>

<style>

</style>