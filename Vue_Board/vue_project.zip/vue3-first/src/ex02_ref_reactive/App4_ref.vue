<template>
    <div class='container'>
        <div>
            {{name}}
        </div>
        <!-- click 이벤트 발생시 nameChange 함수 실행합니다. -->
        <button class="btn btn-primary" @click="nameChange">이름 변경</button>
    </div>
</template>

<script>
/*
    1. 버튼을 클릭하면 콘솔에 홍길동이 출력 되고 template의 {{name}}도 변화됩니다.
    2. 버튼을 클릭하면 값도 반응형 데이터가 될 수 있도록 변경하기 위해 아래와 같이 함수를 import
*/
import {ref} from 'vue';
export default{
    setup(){
        //ref()를 사용하면 name의 값은 속성 value로 접근합니다.
        const name = ref('vue');

        //arrow 함수 표현식
        const nameChange=()=>{
            name.value='홍길동';
            console.log(name.value); //ref()를 사용하면 속성 value로 값에 접근합니다.
        }

        return{
            name : name,
            nameChange : nameChange
        }
    }
}
</script>

<style>

</style>