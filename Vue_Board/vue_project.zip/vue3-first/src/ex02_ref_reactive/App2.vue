<template>

  <div>
    {{ obj }}
  </div>
</template>

<script>
//여기서 @는 src를 의미합니다.
//default 없이 import 한 것은 중괄호 안에 export할 때 사용한 변수 이름을 작성합니다.
import {obj} from '@/ex01_import/test1.js';

export default {
setup(){

    console.log(obj);//{name: "홍길동", age: 21}

    obj.name = 'vue2';//name 속성의 값을 'vue2'로 변경합니다.
                        //속성값을 변경하면 화면에서 변경된 값이 적용됩니다.
    return{
      obj : obj
    }
  }
}
</script>

<style>

</style>