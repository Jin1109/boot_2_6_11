<template>
    <div class='container'>
        <div>
            {{name}}
        </div>
        <!-- click 이벤트 발생시 nameChange 함수 실행합니다. -->
        <button class="btn btn-primary" @click="nameChange">이름 변경</button>
    </div>
</template>

<script>
/*
    버튼을 클릭하면 콘솔에 홍길동이 출력되지만 template의 {{name}}은 변화가 없습니다.
    아직 반응형 데이터가 아닙니다.
*/
export default{
    setup(){

        let name = 'vue';
        const nameChange=()=>{
            name='홍길동';
            console.log(name);
        }

        return{
            name : name,
            nameChange : nameChange
        }
    }
}
</script>

<style>

</style>