<template>
    <div class='container'>
        <div>
            {{name}}
        </div>
          
        <button class="btn btn-primary" @click="nameChange">이름 변경</button>
    </div>
</template>

<script>
/*
    1. reactive()는 객체나 배열을 반응형 데이터로 처리합니다.
    2. 기본형 (String), 숫자 등은 반응형으로 처리하지 않습니다.
    3. {tittle : 'vue'} 객체에 저장한 title 속성의 값은 변경된 내용이 출력됩니다.
*/
import {reactive} from 'vue';
export default{
    setup(){
        
        const name = reactive('vue');
        const nameChange=()=>{
            name.title='홍길동';
            console.log(name); //ref()를 사용하면 속성 value로 값에 접근합니다.
        }

        return{
            name : name,
            nameChange : nameChange
        }
    }
}
</script>

<style>

</style>