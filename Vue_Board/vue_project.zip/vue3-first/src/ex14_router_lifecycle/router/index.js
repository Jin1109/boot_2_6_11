/*
 1. Vue Router는 단일 페이지 애플리센이션을 구측하기 위한 vue.js 확장 라이브러리입니다.
 컴포넌트와 URL 을 연결해 주는 기능을 가지고 있습니다.

 https://router.vuejs.org/installation.html
 https://router.vuejs.org/guide/essentials/navigation.html

 2. router 설치
    c:\vue_project\vue3-first>npm install vue-router@4

 3.creatRouter()로 라우터를 생성합니다.

 4. 라우터를 생성시 history, routes 를 작성합니다.
    1) history
        (1)  history :    createWebHashHistroy()
             localhost:8081/으로 접속하면 localhost:8081/#/로 나타납니다.
             회원정보를 클릭한 경우 - http://localhost:8081/#/vue/info
        (2)  history : creatWebhistory()
             #이 나타나지 않습니다.
    2)  routes
        routes 옵션을 통해서 path(이동 URL), name(여러  route를 구분할 이름),
        component(이동시 실행될 컴포넌트)를 정의합니다.
        
 5. router-view
        <router-link>이동 하면 컴포턴트가 <router-view>에 나타납니다.     
 */

//import {createRouter,     createWebHashHistroy } from 'vue-router';
import { createRouter,     createWebHistory } from 'vue-router';
import Info from '../component/infoView.vue'; 
import Board from '../component/boardView.vue'; 
import Update from '../component/updateView.vue';
import Login from '../component/loginView.vue';
const router = createRouter({
    //history : createWebHashHistory(), //주소에 #이 나타납니다. 예) http://localhost:8081/#/vue/board
    history : createWebHistory(),
    routes : [
    {
        path:'/vue',
        name : 'Home',
        component : Board
    },    
    {
        path:'/vue/update',
        name : 'Update',
        component : Update
    },
    {
        path:'/vue/info',
        name : 'Info',
        component : Info
    },
    {
        path:'/vue/board',
        name : 'Board',
        component : Board
    },
    {
        path:'/vue/logout',
        name : 'Login',
        component : Login
    }
]
});

export default router;