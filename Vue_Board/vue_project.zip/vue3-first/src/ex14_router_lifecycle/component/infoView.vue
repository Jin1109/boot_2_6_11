<template>
  <div>
    이곳은 정보를 보여주는 페이지 입니다. (info.vue)
  </div>
</template>

<script>
import {onMounted, onUnmounted} from 'vue'
export default {
  setup(){

    //컴포넌트 인스턴스가 마운트 된 후 호출됩니다.
    onMounted(()=> {
      console.log('[info]Component is mounted!');
    })

    //컴포넌트 인스턴스가 마운트 해제(unmounted)된 후 호출됩니다.
    onUnmounted(()=>{
      console.log('[info]Component is onUnmounted!')
    })
  }
}
</script>

<style>

</style>