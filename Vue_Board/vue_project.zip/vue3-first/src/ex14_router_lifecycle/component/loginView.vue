<template>
  <div>
    이곳은 로그인 페이지 입니다. (login.vue)
  </div>
</template>

<script>
import {onMounted, onUnmounted} from 'vue'
export default {
  setup(){

    //컴포넌트 인스턴스가 마운트 된 후 호출됩니다.
    onMounted(()=> {
      console.log('[login]Component is mounted!');
    })

    //컴포넌트 인스턴스가 마운트 해제(unmounted)된 후 호출됩니다.
    onUnmounted(()=>{
      console.log('[login]Component is onUnmounted!')
    })
  }
}
</script>

<style>

</style>