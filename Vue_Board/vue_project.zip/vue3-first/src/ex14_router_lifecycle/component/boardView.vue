<template>
  <div>
     이곳은 게시판  페이지 입니다.(board.vue)
  </div>     
  <input value="this" ref="el">
</template>

<script>
import {ref, onMounted, onUnmounted, onBeforeMount} from 'vue'
export default {
  setup(){
    const el = ref(null);
    console.log('[board]setup start')
    /*
      https://v3.vuejs.org/guide/composition-api-lifecycle-hooks.html
      https://v3.ko.vuejs.org/api/options-lifecycle-hooks.html#mounted
      https://kr.vuejs.org/v2/guide/components.html
      * Vue.js는 라이프 사이클을 미리 등록해서 적절한 시기에 자동으로 호출합니다.
          이러한 시점을 낚아채서(Hook) 우리가 원하는 처리를 할 수 있게 하는 것을 훅이라고 합니다.
        * 작성법
          1. 사용할 훅을 import 합니다.
            예) import {onMounted, onUnmounted} from 'vue'
          2. 실행할 코드를 매개변수의 콜백함수로 작성합니다.
            예) onUnmounted(()=>{ })
    */
  
  //컴포넌트 인스턴스가 마운트 되기 전(Dom에 추가되기 직전) 호출합니다.
    onBeforeMount(() => {
      console.log('[board]Component is onBeforMount!');
      console.log(el.value);  //null
    })

  //컴포넌트 인스턴스가 마운트 된 후(Dom에 추가된 후) 호출합니다.
    onMounted(() => {
      console.log('[board]Component is mounted!');
      console.log(el.value.value);  //this
    })

  //컴포넌트 인스턴스가 마운트 해제(unmounted)된 후 호출합니다.
    onUnmounted(() => {
      console.log('[board]Component is onUnmounted!');
      console.log(el.value);  //null
    })

    console.log('[board]setup end')
    
    return{
      el
    }
  }
}
</script>
  
<style>

</style>