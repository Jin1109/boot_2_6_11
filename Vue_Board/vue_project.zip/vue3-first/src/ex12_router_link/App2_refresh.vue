<template>
<!-- session에 값이 있는 경우 : 메뉴바 생성 확인합니다. -->        
  <nav class="navbar navbar-expand-sm right-block navbar-dark" v-if="id">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="logout">{{id}}님(로그아웃)</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="update">정보수정</a>
      </li>

      <!-- admin 메뉴 -->
      <div v-if="id=='admin'">
        <!-- Dropdown -->
        <li class="nav-item dropdown"><a
            class="nav-link dropdown-toggle" href="#" id="navbardrop"
            data-toggle="dropdown"
            > 관리자 </a>
            <div class="dropdown-menu" >
              <!-- herf="info" : 페에지 새로고침 됩니다.-->
              <a class="dropdown-item" href="info">회원정보</a>
              <a class="dropdown-item" href="board">게시판</a>
            </div></li>
      </div>
    </ul>
  </nav>
</template>

<script>
import axios from './axiossetting.js'
import {ref } from 'vue';
export default {
    setup(){
        const id = ref('');
        const getSession = async()=>{
            try{
              
                const res = await axios.get("getSession_ex"); 
                console.log("res="+res.data)
                id.value=res.data;
                if(id.value==''){ //null은 값으론 빈문자열로 리턴
                  console.log('null');
                }
            }catch(err){
                console.log(err);
            }
        }

        getSession();

        return{
          id
        }
    }
}
</script>

<style scoped>
   nav.navbar {
   justify-content: flex-end; /* 오른쪽 정렬 */
}

.dropdown-menu {
min-width: 0rem; 
}

/* nav 색상 지정 */
.navbar {
   background: #096988;
   margin-bottom: 3em;
   padding-right: 3em;
}

.navbar-dark .navbar-nav .nav-link {
   color: rgb(255, 255, 255);
}

.dropdown-menu a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-menu {
  display: block;
}

</style>\