<template>
  <form name="loginform">
    <h1>로그인</h1>
    <hr>
    <b>아이디</b>
    <input type="text" name="id" placeholder="Enter id" required>

    <b>Password</b>
    <input type="password" name="password" placeholder="Enter password" required>
    <label>
      <input type="checkbox" name="remember" style="margin-bottom:15px"> Remember me
    </label>
    <div class="clearfix">
      <button type="submit" class="submitbtn">로그인</button>
      <button type="button" class="join" @click="join">회원가입</button>
    </div>
  </form>

</template>

<script>
import {useRouter} from 'vue-router';
export default {
  setup(){
    const router = useRouter(); //useRouter()는 라우터 인스턴스를 반환합니다.
    const join = ()=>{
          //이동할 주소는 라우터의 push()를 이용합니다.
          //https://router.vuejs.org/guide/essentials/navigation.html
          router.push({
            name:'Join'
          });
    }
    
    return{
      join
    }
  } 
}     
</script>

<style scoped>
* {box-sizing: border-box}

input[type=text], input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer; /* 손가락 커서 모양 */
    width: 100%;
    opacity: 0.9;
}

button:hover {
    opacity:1;
    
}
button:focus{
   outline:none;
}

/* 취소 버튼*/
.join{
    padding: 14px 20px;
    background-color: #f44336;
}

.join, .submitbtn {
  height:45px;
  float: left;
  width: 50%;
}
a{color:white;text-decoration:none;}

form {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 50%; /* Could be more or less, depending on screen size */
    padding: 16px;
}

hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}
 
/* Clear floats */
.clearfix::after {
    content: "";
    clear: both;
    display: table; 
}

</style>