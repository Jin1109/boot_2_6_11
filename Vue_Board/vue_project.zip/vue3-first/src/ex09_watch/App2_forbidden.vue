<template>
  
  <div class="container">
        <p> 금지문자&lt;script&gt;</p>
        <textarea v-model="message" rows="10" cols="50"></textarea>
  </div>      
</template>

<script>
import {ref, watch} from 'vue';
export default {
  setup() {
    const forbiddenText = '<script>';
    const message = ref('');
    watch(message,()=>{
        console.log(message.value);
        let index = message.value.indexOf(forbiddenText);
        console.log(index);
        if(index>=0){
            alert(forbiddenText + "는 입력할 수 없습니다.");
            message.value = message.value.substring(0,index);
        }
    })

    return {
            message
        }
  }
}
</script>

<style>

</style>