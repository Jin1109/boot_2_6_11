<template>
    <!--
        1. 조건에 따라 HTML이 나타났다 사라집니다.
            v-if는 조건에 따라 컴포넌트가 실제로 제거되고 생성됩니다.
        2. 형식)
            <태그명 v-if="조건">조건이 true이면 표시됩니다.</태그명>

        3. https://v3.ko.vuejs.org/guide/conditional.html
            v-else 디렉티브를 사용하여 v-if에 대한 "else 블록"을 나타낼 수 있습니다.
            v-else 엘리먼트는 반드시 v-if 엘리먼트나 v-else-if 엘리먼트 바로 뒤에 와야 합니다.
            그렇지 않으면 인식되지 않습니다.
    -->
 <div class="container">
        <label><input type="checkbox" v-model="isChecked">체크 여부 {{isChecked}}</label>
        <div v-if="isChecked">체크 박스를 선택하셨습니다.</div>
        <div v-else>체크 박스를 해제 하셨습니다.</div>
 </div>
</template>

<script>
import {ref} from 'vue';
export default{
    setup(){
        const isChecked = ref(true)

        return{
            isChecked
        };      
    }
};
</script>

<style >
 
</style>