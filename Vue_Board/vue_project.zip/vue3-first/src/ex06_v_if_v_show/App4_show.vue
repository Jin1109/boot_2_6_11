<template>
    <!--
        v-show : 단순히 css 의 display 속성만 변경됩니다.
        state 에 따라 보여졌다 안보여졌다하느 빈도가 많다면 v-show 를 사용합니다.
        v-if 의 경우 태그를 그렸다 지웠다 해야되기 때문에  브라우저가 많은 부담을 느낍니다.
        하지만 이런 경우를 제외한다면 v-if 를 잉ㅇ하면 됩니다.

        <div class="container">
            <input type="text" v-model="su">
            <div v-if="su=='0'">0입니다.</div>
            <div v-else-if="su=='1'">1입니다.</div>
            <div v-else>0 또는 1이 아닙니다.</div>
        </div>
    -->
 <div class="container">
        <input type="text" v-model="su">
        <div v-show="su=='0'">0입니다.</div>
        <div v-show="su=='1'">1입니다.</div>
        <div v-show="su!='0' && su!='1'">0 또는 1이 아닙니다.</div>
 </div>
</template>

<script>
import {ref} from 'vue';
export default{
    setup(){

        const su = ref('0')

        return{
            su
        };      
    }
};
</script>

<style >
 
</style>