<template>
    <!--
        1. 조건에 따라 HTML이 나타났다 사라집니다.
            v-if는 조건에 따라 컴포넌트가 실제로 제거되고 생성됩니다.

        2. 형식)
            <태그명 v-if="조건">조건이 true이면 표시됩니다.</태그명>
    -->
 <div class="container mt-3">
        <button v-on:click="add" class="btn btn-warning">값 증가</button>
        <p>{{count}}</p>
        <p v-if="count!=0">{{count}}</p>
    </div>
</template>

<script>
import {ref} from 'vue';
export default{
    setup() {
        const count = ref(0);

        const add = ()=>{
            count.value++;
        }
        return{
            count, add
        };      
    }
};
</script>

<style >
 
</style>