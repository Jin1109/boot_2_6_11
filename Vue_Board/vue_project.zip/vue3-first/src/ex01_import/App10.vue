<template>

    <div class='container'>


    </div>
</template>

<script>

//default가 없는 export의 경우 import시 중괄호를 사용합니다.
//여기서 @는 src를 의미합니다.
import {sayHi, GoodBye} from '@/ex01_import/test6.js';

//setup() 안에 데이터와 메서드 작성합니다.
export default{
    setup(){
        sayHi('Vue.js');
        GoodBye('Vue.js');
        return{

        }
    }
}
</script>

<style >

</style>