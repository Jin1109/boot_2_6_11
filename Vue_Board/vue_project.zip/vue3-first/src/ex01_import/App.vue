<!-- vue라고 입력 후=> 첫 번째  default.vue 선택해 보세요 -->
<template>
    <div class='container red'>처음으로 작성하는 vue.js</div>
</template>

<script>
//자바스크립트 영역입니다.
export default {
    setup() {
        console.log('자바스크립트 영역입니다.');
    },
}
</script>

<style scoped>
/* 스타일 영역 */
.red{color:red}
</style>
