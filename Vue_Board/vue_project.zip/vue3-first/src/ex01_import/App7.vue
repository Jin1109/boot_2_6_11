<template>

    <div class='container'>


    </div>
</template>

<script>

//여기서 @는 src를 의미합니다.
import {sayHi, sayHi2 }from '@/ex01_import/test3.js';

//setup() 안에 데이터와 메서드 작성합니다.
export default{
    setup(){
        sayHi('Vue.js');
        sayHi2('Vue2.js');
        return{

        }
    }
}
</script>

<style >

</style>