<template>
  <div class='container blue'>
    const와 let을 사용합니다.
  </div>
</template>

<script>

//setup() 안에 데이터와 메서드 작성합니다.
export default {
setup(){
    const a = "나는 한 번 설정하면 값을 변경할 수 없어요";
    console.log(a);

//error 'a' is constant no-const-assign
    //a='나는 에러가 나요';
    
    let b = '나는 값을 변경할 수 있어요';
    console.log(b);
    b='변경되었나요?(let b)';
    //let b = '하하';
  }
}
</script>

<style scoped>
/* 스타일 영역 */
.blue{color:blue}
</style>