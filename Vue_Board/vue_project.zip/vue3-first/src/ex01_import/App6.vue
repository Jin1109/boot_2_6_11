<template>

    <!--
      1.Mustache 기법
          텍스트 콘텐츠의 해당 위치에 {{      }}를 사용하면 스크립트 안의 return된
          속성(프로퍼티)을 작성하면 됩니다.
      2. 데이터 바인딩
          자바스킙트의 데이터와 template에서 이름 사용하는 위치 곳을 연결해서 데이터에 벼녁이
          자동으로 DOM을 업데이트 하는 기능입니다.        
    -->

  <div class='container'>
    <ol>
        <li>{{ fruit }} </li>
        <li>{{ fruit[0]}}</li>
        <li>{{ fruit[1]}}</li>
        <li>{{ fruit[2]}}</li>
        <li>{{ fruit[3]}}</li>
    </ol>
  </div>  

</template>

<script>

/*
1. 현재 App5.vue의 위치(src/ex01_import)를 기준으로 test1.js위치를 상대경로로 작성하는 경우
    (1) 같은 폴더에 존재하는 경우 반드시 현재경로를 의미하는 (.)과 슬래쉬 그리고 파일명을 작성합니다.
    (2) 예) import {fruit, obj} from './test1.js';

2. @를 사용해 절대 경로로 작성하는 경우
    vue파일 위치에 상관없이 vue 프로젝트 바로 아래에 있는 src로 경로를 지정하는 경우 입니다.
    (1) 여기서 @는 src를 의미합니다.
    (2) 예) import {fruit, obj} from '@/ex01_import/test1.js';
*/

//export const fruit = ['사과', '배', '복숭아', '참외'];
//export const obj={'name':'홍길동', 'age':21}
//default 없는 export를 import 할 때 중괄호 안에 export할 때 사용한 변수 이름을 작성합니다.
import fruit from '@/ex01_import/test2.js';

//setup() 안에 테이터와 메서드 작성합니다.
export default {
  setup(){

    return{
       fruit:fruit
    }  
  }
}


</script>

<style>

</style>