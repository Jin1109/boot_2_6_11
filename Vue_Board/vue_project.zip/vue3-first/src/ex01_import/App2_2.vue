<template>

    <!--
      1.Mustache 기법
          텍스트 콘텐츠의 해당 위치에 {{      }}를 사용하면 스크립트 안의 return된
          속성(프로퍼티)을 작성하면 됩니다.
      2. 데이터 바인딩
          자바스킙트의 데이터와 template에서 이름 사용하는 위치 곳을 연결해서 데이터에 벼녁이
          자동으로 DOM을 업데이트 하는 기능입니다.        
    -->

  <div class='container'>
    <h5> 2. 리턴된 속성과 값의 이름이 다른 경우 </h5>

    <ol>
        <li>
            fruit[0] : {{ fruit[0]}}
        </li>
        <li>
            fruit[1] : {{ fruit[1]}}
        </li>
        <li>
            fruit[2] : {{ fruit[2]}}
        </li>
        <li>
            fruit[3] : {{ fruit[3]}}
        </li>
    </ol>
    <p> fruit : {{ fruit }} </p>
  </div>  

</template>

<script>

//setup() 안에 테이터와 메서드 작성합니다.
export default {
  setup(){
    const fruit = ['사과', '배', '복숭아', '참외'];

    /*
      1.리턴문에 사용되는 자료형은 객체입니다.
      2. 객체는 속성과 값으로 작성합니다.
      3. 만약 속성과 값을 같은 이름으로 사용하면 콜론없이 사용 가능합니다.
      예) fruit:fruit => fruit
    */
    return{
       fruit:fruit
    }  
  }
}
</script>

<style>

</style>