/*
애로우 함수 사용법
1. 형식
    (매개변수 리스트)=> {문장들}
    (param1, param2, ..., paramN) => { statements }

2. 애로우 함수는 항상 익명입니다.

3. 매개변수가 한 개인 경우 소괄호는 선택사항입니다.
    (singleParam) => { statements }
    singleParam   => { statements }

4. 매개변수가 없는 경우 소괄호는 필수입니다.
    예) () => {statements}
*/
export const sayHi = (user) => {
    console.log(`Hi*****, ${user}!`);
} //닫는 중괄호 뒤에 세미콜론이 오면 오류 발생합니다.

export const GoodBye = (user) => {
    console.log(`GoodBye*****, ${user}!`);
} //닫는 중괄호 뒤에 세미콜론이 오면 오류 발생합니다.
