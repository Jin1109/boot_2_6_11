export const fruit = ['사과', '배', '복숭아', '참외'];

export const obj = {'name':'홍길동', 'age':21}