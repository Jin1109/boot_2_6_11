function sayHi(user) {
    //문자열 + 변수의 형태로 문자열을 만듬
    console.log('Hi, ' + user + '!');
} //닫는 중괄로 뒤에 세미콜론이 오면 오류 발생합니다.

function sayHi2(user) {
    //백틱(`)을 이용한 문자열 서식(템플릿 리터럴)
    //백틱안에 $(변수명)을 이용해서 문자열(템플릿 리터럴) 서석을 만듬
    console.log(`Hi, $(user)!`);
} //닫는 중괄로 뒤에 세미콜론이 오면 오류 발생합니다.


//export {}를 이용한 내보내기 방법
export {sayHi, sayHi2}; // {}안에 내보낼 함수명을 작성합니다. 