export const fruit = ['사과', '배', '복숭아', '참외'];
export default fruit;

//위 문장들을 한 줄롤 표현하면 다음과 같습니다.
//export defaulut ['사과', '배', '복숭아','참외'];