<template>

    <div class='container'>


    </div>
</template>

<script>

//default가 없는 export의 경우 importtl 중괄호를 사용합니다.
//여기서 @는 src를 의미합니다.
import {sayHi} from '@/ex01_import/test5.js';

//setup() 안에 데이터와 메서드 작성합니다.
export default{
    setup(){
        sayHi('[App9.vue]Vue.js');
        return{

        }
    }
}
</script>

<style >

</style>