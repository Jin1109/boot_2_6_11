<template>
  <!--
    1. HTML 태그를 반복해서 표시하고자 사용하는 것이 v-for 디렉티브입니다.
       배열 테이터나 반복 표시 또는 회수를 지정해서 반복 표시하도록 만들 수 있습니다.
    2. 형식)
       (1) <태그명 v-for="변수 in 최대값"> 반복 부분 </태그명>
           숫자가 1부터 최대값까지 1씩 증가합니다.

       (2) <태그명 v-for="변수 in 배열"> 반복 부분 </태그명 >
           배열에서 하나씩 꺼내 변수에 담습니다.

       (3) <태그명 v-for="(변수,인덱스) in 배열"> 반복 부분 </태그명>
           인텍스는 0부터 시작  

    3. v-key
        (1) v-bind:key directive를 사용하라는 에러 메시지가 나타납니다.
        (Elements in iteration expect to have 'v-vind:key' directives
        vue/required-v-for-key)

        (2) https://kr.vuejs.org/v2/guide/list.html#v-for-와-컴포넌트
            2.2.0 이상에서 v-for는 key 가 필수 입니다
            
        (3) https://kr.vuejs.org/v2/guide/list.html?#기본-사용방법
        Vue에서 개발 DOM 노드들을 추적하고 기존 엘리먼트를 재사용,
        재정렬하기 위해서 v-for의 각 항목들에 고유한 key 속성을 제공해야 합니다.
        key에 대한 이상적인 값은 각 항목을 식별할 수 있는 고유한 ID입니다.
        문자들이나 숫자를 사용하세요.



  -->
  
  <div class="container" >
    <div> 배열의 push()메서드는 배열의 맨 마지막에 데이터를 추가흔 메서드 입니다.</div>
    <div> 이름을 입력하고 엔터를 치면 name_list의 맨 마지막에 추가합니다. </div>
    <input tpye="text" v-model="input_data" class="form-control" v-on:keyup.enter="add">
    <table class="table table-striped">
        <caption><h3>name list</h3></caption>
        <tbody>
            <tr><th>번호</th><th>이름</th></tr>   
            <tr v-for="(item, index) in name_list" :key="index">
                <td>{{++index}}</td> <td>{{item}}</td>
            </tr>
        </tbody>       
    </table>
  </div>          
</template>

<script>
import {ref} from 'vue'
export default{
    setup(){
        const  name_list = ref(['홍길동','이순신','신사임당']);
        const  input_data = ref('');


        const  add = ()=>{
            name_list.value.push(input_data.value);
        }

        return{
            name_list, input_data, add
        };      
    }
};
</script>

<style scoped>
caption{ caption-side: top; text-align: center}
</style>