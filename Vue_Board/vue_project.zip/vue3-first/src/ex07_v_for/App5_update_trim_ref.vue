<template>
  <div class="container" >
    <!-- ref 속성으로 직접 DOM 객체에 접근할 수 있습니다.
    1. 태그에 ref="f2" 처럼 ref속성과 값을 작성합니다.

    2. script에서 ref속성의 값에 해당하는 변수를 반응형으로 생성합니다.
       const f2=ref(null);

    3. 포커스를 주고자 할 때는 focus()를 이용합니다.
       f2.value.focus()
  -->
    <input tpye="text" v-model.trim="input_data" class="mt-3 form-control" 
            v-on:keyup.enter="add" ref="f2">
    <h5>
        <ol><li> 추가 - 입력상자에 이름을 입력 후 엔터</li>
            <li> 수정 - 입력사장에 이름을 입력 후 수정을 원하는 버튼 클릭 </li>
            <li> 삭제 - 선택한 로우 삭제splice(index,1) </li></ol>
    </h5>        
    <table class="table table-striped">
        <caption><h3>name list</h3></caption>
        <tbody>
            <tr><th>번호</th><th>이름</th><th>수정</th><th>삭제</th></tr>   
            <tr v-for="(item, index) in name_list" :key="index">
                <td>{{index + 1}}</td><td>{{item}}</td> 
                <td><button class="btn btn-primary" v-on:click="update(index)">수정</button></td>
                <td><button class="btn btn-danger" v-on:click="del(index)">삭제</button></td>
            </tr>
        </tbody>       
    </table>
  </div>          
</template>

<script>
import {ref} from 'vue'
export default{
    setup() {
        const  name_list = ref(['홍길동','이순신','신사임당']);
        const  input_data = ref('');
        const f2=ref(null);

        const  add = ()=>{
            if(input_data.value==''){
                alert('데이터를 입력하세요.');
                return;
            }
            //배열 끝에 데이터 추가
            name_list.value.push(input_data.value);

            //입력한 데이터 초기화
            input_data.value='';
        }

        const update = (index)=>{
            //입력하지 않고 수정 버튼 클릭한 경우
            if(input_data.value==''){
                alert('데이터를 입력하세요.');
                f2.value.focus(); //input에 포커스
                return;
            }
            //수정버튼 위치의 값을 입력한 값으로 변경합니다.
            name_list.value[index] = input_data.value;

            input_data.value=''; //입력한 데이터 초기화

            f2.value.focus(); //input에 포커스 주기
        }

        const del = (index)=>{
            if(!confirm("정말 삭제 하시겠습니까?")){ //취소를 선택할 경우
                return;
            }
            /*
                배열 위치에서 삭제 갯수 만큼 삭제합니다.
                형식) splice(위치, 삭제 갯수)
                      splice()의 반환형은 삭제된 데이터입니다.
            */
            //배열 index 위치에서 1개를 삭제합니다.
            name_list.value.splice(index,1);
        }

        return{
            name_list, input_data, add, update, del, f2
        };      
    }
};
</script>

<style scoped>
caption{ caption-side: top; text-align: center}
</style>