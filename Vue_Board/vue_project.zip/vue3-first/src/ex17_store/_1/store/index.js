import {createStore} from 'vuex';
export default createStore({
    //공통으로 사용할 변수를 정의합니다.
    state:{
        message:'초기값'
    },
    mutations:{ //state의 값을 변경하는 곳입니다.
    
    },
    actions:{ //mutations를 실행시키는 역할을 합니다.
    
    }
});