<template>
  <div>[child]store에서 가져온 값 : {{message}}</div>
</template>

<script>
import {useStore} from 'vuex';
import {ref} from 'vue';
export default {
  setup(){
    const store = useStore();

    let message = ref('');
    message.value = store.state.message;

    return {
        message
    }
  }
}
</script>

<style scoped>
    div{background: rgb(191, 221, 145);}
</style>