<template>
  <div class="parent">
    <child></child>
    [parent]{{store_message}}
  </div>  
</template>

<script>
import child from './childView.vue';
import {ref} from 'vue';
import {useStore} from 'vuex';
export default {
    components:{
        child
    },
    setup(){
        /*
    store영역의 state.message에 접근하기 위해 아래와 같은 방법으로 접근합니다.
    (1) 일반적인 접근
       import {useStore} from 'vuex';
       consts store = useStore();
       const msg = store.state.message;

    (2) 구조 분해 할당으로 접근
       import {useStore} from 'vuex';
       const {state} = useStore();
       const msg = state.message;
       
    (3) 참고
       자바스크립트의 구조 분해 할당 예 입니다.
       let person = {name : '자바스크립트', age : '21'}
       여기서 name의 값을 얻기 위한 방법 입니다
       ① let name = person.name; //기존 방식

       ② let {name} = person;    //구조 분해 할당

       구조 분해 할당 구문은 배열이나 객체의 속성을 해체하여
       그 값을 개별 변수에 담을 수 있게 하는 JavaScript 표현식입니다.
    */
      const store_message=ref('');
      //const store = useStore();
      //store_message.value = store.state.messge;

      const {state} = useStore();
      store_message.value = state.message;

      return{
        store_message
      }
    }
}
</script>

<style scoped>
  .parent{background: rgb(226, 201, 226);}
</style>