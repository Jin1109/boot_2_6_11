<template>
  <div>[child] store에서 가져온 값 : {{store_message}}</div>
  <div>[child] 자식에서 입력합니다.:<input @input="change"></div>

</template>

<script>
import {useStore} from 'vuex';
import {computed} from 'vue';
export default {
  setup(){
    const store = useStore();

    //state.state.message의 값이 바뀌면 message의 내용도 바뀝니다.
    const store_message = computed(() => store.state.message);

    const change = (event)=>{
        //stor.dispatch()를 통해 store의 actions 안의 'update' 함수를 호출하도록 합니다.
        //child_message.value는 전달할 값입니다.
        //이곳에서 입력한 값을 부모 컴포넌트에서도 적용될 수 있도록 store의 state가 관리하고 있는 
        //message 값을 변경하도록 합니다.
        store.dispatch('update', event.target.value);
    }
    return {
        store_message, change
    }
  }
}
</script>

<style scoped>
    div{background: rgb(189, 223, 146);}
</style>