<template>
  <div class="parent">
    <child></child>
      [parent]store에서 가져온 값 :{{store_message}}<br>
      부모에서 입력합니다. <input @input="change">
  </div>
</template>

<script>
import child from './childView.vue';
import {computed} from 'vue';
import {useStore} from 'vuex';
export default {
  components:{
    child
  },
  setup(){
    const store = useStore();

      //store.state.message의 값이 바뀌면 store_message의 내용도 바뀝니다.
    const store_message = computed(() => store.state.message);

    const change = (event)=>{
      store.dispatch('update', event.target.value);
    }

    return{
      change, store_message
    }
  }
}
</script>

<style scoped>
  .parent{background: rgb(219, 207, 228);}
</style>