<template>
  <div>[child] store에서 가져온 값 : {{message}}</div>
</template>

<script>
import {useStore} from 'vuex';
import {computed} from 'vue';
export default {
  setup(){
    const {state} = useStore();

    //state.message의 값이 바뀌면 message의 내용도 바뀝니다.
    const message = computed(
          () => state.message
    );
    return {
        message
    }
  }
}
</script>

<style scoped>
    div{background: rgb(191, 221, 145);}
</style>