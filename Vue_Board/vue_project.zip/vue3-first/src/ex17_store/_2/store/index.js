import {createStore} from 'vuex';
export default createStore({
    //공통으로 사용할 변수를 정의합니다.
    state:{
        message:'초기값'
    },
    mutations:{ //state의 값을 변경하는 곳입니다.
                //mutations를 실행 시키는 역할을 하는 actions에서
                //commit('함수명','전달인자')로 실행시킬 수 있습니다.
        update_id(state, payload){//update_id는 commit()에서 사용된 첫번째 '함수명'입니다.
                                  //첫번째 매개변수 state는 mutations에서 state속성을 사용할 수 있도록
                                  //두번째 매개변수는 commit()에서 사용된 두번째 '전달인자'입니다.
          state.message = payload; //5번라인 state의 속성 message에 전달인자값을 대입합니다.
          console.log('[store/index.js]mutations = ' + payload);
        }
    
    },
    actions:{ //mutations를 실행시키는 역할을 합니다.
              //mutations이 실행되면 state도 변경됩니다. - 비동기 처리합니다.
              //dispatch('함수명','전달인자')로 실행 시킬 수 있습니다.
        update(context, getMessage){//update는 dispatch()에서 사용된 첫번째 함수명입니다.
                                    //첫번째 매개변수는 context는 commit()를 실행시킬 수 있는 객체를 전달
                                    //두번째 매개변수는 getMessage는 dispatch()의 '전달인자'입니다.
                                    //context.commit(mutations에 정의된 함수 이름, 함수에 넘길 값)
          context.commit('update_id', getMessage);
          console.log('[store/index.js]actions= ' + getMessage);
        }
    
    }
});