<template>
  <div class="parent">
    <child></child>
    [parent]store에서 가져온 값 :{{store_message}}<br>
      부모에서 입력합니다. <input @input="change" :value="store_message">
  </div>
</template>

<script>
import child from './childView.vue';
import {ref} from 'vue';
import {useStore} from 'vuex';
export default {
  components:{
    child
  },
  setup(){
    const store_message=ref('');
    const store = useStore();
    store_message.value = store.state.message;

    //부모에서 입력한 값의 변화가 있으면 store에 저장되도록 
    //store.duspatch('actions 함수명', '저장할 값')를 호출합니다.
    //store에서 actions의 update()가 실행됩니다.
    const change = (event)=>{
      store.dispatch('update', event.target.value);
    }

    return{
      change, store_message
    }
  }
}
</script>

<style scoped>
  .parent{background: rgb(226, 201, 226);}
</style>