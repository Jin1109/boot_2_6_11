<template>
  <div class="container">
    <table class="table table-stripped">
        <caption>
            <h3>name list</h3>
        </caption>
        <tr>
            <th>번호</th>    
            <th>이름</th>    
            <th>나이</th>    
        </tr>

        <tr v-for="(item, index) in list" :key="index">
            <td>{{item.id}}</td>    
            <td>{{item.name}}</td>    
            <td>{{item.age}}</td>
        </tr>
    </table>
    <div class="error">{{error}}</div>
  </div>            
</template>

<script>
import axios from 'axios';
import {ref } from 'vue';
export default {
    setup(){
        const list = ref([]);
        const error = ref('');

        /*
    1. axios는 HTTP 비동기 통신 라이브러리 입니다.

    2. REST API의 HTTP 메서드(GET, POST, PUT, PATCH, DELETE)를 이용할 수 있습니다.

    3. REST API
        1) REST API(RESTful API, 레스트풀 API)란 REST 아키텍처의 제약 조건을 준수하는 
        애플리케이션 프로그래밍 인터페이스를 뜻합니다.

        2) REST는 Representational State Tramsfer의 약자입니다.

        3) HTTP URI(Uniform Resource Identifier)를 통해 자원(Resource)을 명시하고,
           HTTP Method(POST, GET, PATCH, PUT, DELETE)를 통해 해당 자원에 대한 
           CRUD Operation을 적용하는 것을 의미합니다.
           예) JSP 프로젝트에서 request,getRequestURL(), request,getRequestURI()로 확인했던 URL과 URI입니다.
            요청 URL : http://localhost:8088/JSP/ex_implicit_object/_3.requestget/requestTest3.jsp
            요청 URL(Uniform Resource Identifier) : /JSP/ex3_implicit_object/_3.requestget/reuqestTest3.jsp

        4) CRUD Operation
            Create : 생성(POST)
            Read : 조회(GET)
            Update : 수정(Update)
            Delete : 삭제(Delete)

        5) 설계예시
                              전송방식
            특정 리소스 조회    -GET       -    /members/{id}
            전체 리소스 조회    -GET       -    /members
            리소스 생성         -POST      -    /members
            리소스 일부 수정    -PATCH     -    /members
            특정 리소스 삭제    -DELETE    -    /members/{id}
    
    4. axios를 사용하기 위해 라이브러리를 설치합니다.
       C:\vue_project\vue3-first>npm install axios
    
    5. 비동기 방식으로 HTTP 데이터 요청을 실행합니다.
       예) axios.get(요청주소).then(콜백함수-요청 후 처리할 내용 적성하는 곳);

    6. 요청 방식
       1) axios.get(url[,config]) : 서버로 부터 데이터를 가져올 때 사용합니다.
           (예1)    axios.get('http://localhost:8088/vue/users')
           (예2)    axios.get('http://localhost:8088/vue/users?id=${id}')
           (예3)    axios.get('http://localhost:8088/vue/users', {params : {id:join.value.id}})
        
       2) axios.post(url[,config]) : 서버로 데이터를 입력하기 위해 사용합니다.
           (예)     axios.post('http;//localhost:8088/vue/users', {
                                            name: input_name.value,
                                            age: input_age.value,
                    });
       3) axios.delete (url[,config]) : 특정 값에 해당하는 로우 삭제하기 위해 사용합니다.
           (예)     axios.delete('http://localhost:8088/vue/users.${id}');
           
       4) axios.patch (url[,config]) : 특정 값에 해당하는 로우 수정하기 위해 사용합니다.
           (예) axios.patch('http://localhost:8088/vue/users', {
                    name: input_name.value,
                    age: input_age.value,
                    id: _id
                });
    7. 비동기 전송인 axios의 결과 화면
        난 getList End
        성공
        => 동기 전송으로 바꾸기 위해 async와 await를 사용합니다.

    8. 테이블 생성합니다
        (1) vue 테이블 작성하기
          create table vue(
            id numder(5) primary key.
            name varchar2(10 char),
            age number(2)
          );

        (2) 시쿼스 생성합니다.
           create sequence vue_seq;  
*/
        const getList = () => {
            try {
                axios.get('http://localhost:8088/vue/users')
                .then(()=>{
                                console.log('성공')
                });
            } catch (err) {
            console.log(err);
            error.value = 'Something went wrong.';
            }
            console.log('난 getList End')
        };

        getList();

        return {
            list, error
        }
    }
}
</script>

<style>
 caption{caption-side: top; text-align: center}
 .error{color:red}
</style>