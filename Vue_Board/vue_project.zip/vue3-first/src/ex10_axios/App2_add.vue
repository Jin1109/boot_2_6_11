<template>
  
  <div class="container">
    <form @submit.prevent="add"> <!--@submit.prevent : submit 이벤트 발생시 이동하지 않습니다. -->
      <div class="input-group mb-3 mt-3">
        <div class="input-group-prepend">
            <span class="input-group-text">이름</span>
        </div>
        <input
          type="text"
          placeholder="Username"
          v-model="input_name"
          class="form-control"
          required
          />
      </div>
      <div class="input-group mb-3 mt-3">
        <div class="input-group-prepend">
           <span class="input-group-text">나이</span>
        </div>
        <input
          type="text"
          placeholder="Userage"
          v-model="input_age"
          class="form-control"
          required
          maxLength="2"
          pattern="[0-9]{1,2}"
        >
      </div>
      <button type="submit" class="btn btn-info">추가</button>
      <div class="error">{{error}}</div> 
    </form>

    <table class="table table-striped">
            <caption>
                <h3>name list</h3>
            </caption>
            <tr>
                <th>번호</th>
                <th>이름</th>
                <th>나이</th>
            </tr>

            <tr v-for="(item, index) in list" :key="index">
                <td>{{item.id}}</td>
                <td>{{item.name}}</td>
                <td>{{item.age}}</td>
            </tr>
    </table>
  </div>      

                   
</template>

<script>
import axios from 'axios';
import {ref} from 'vue'
export default{
    setup(){
        const list = ref([]);
        const error = ref('');
        const input_name=ref('');
        const input_age=ref(0);

        const getList = async () =>{
            try{
                const res = await axios.get('http://localhost:8088/vue/users')
                list.value = res.data.list;
            } catch (err) {
                console.log(err);
                error.value = '데이터를 가져오는데 오류입니다.';
            }
        };

        getList();
        
        const add = async () => {
            error.value = '';
            try{
                const res = await axios.post('http://localhost:8088/vue/users', {
                    name: input_name.value,
                    age: input_age.value
                });
                console.log("inset 후 = " + res.data);
                getList;
                input_name.value='';
                input_age.value='';
            } catch (err) {
                console.log(err);
                error.value = '삽입 오류 입니다.'
            }
        };

        return{
          list, error, add, input_name, input_age
        }      
    }
};
</script>

<style scoped>
   caption{caption-side: top; text-align: center}
   .error{color:red}
</style>
