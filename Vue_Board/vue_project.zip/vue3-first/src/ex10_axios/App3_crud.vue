<template>
  <div class="container">
    <form @submit.prevent="add"> <!--@submit.prevent : submit 이벤트 발생시 이동하지 않습니다. -->
      <div class="input-group mb-3 mt-3">
        <div class="input-group-prepend">
            <span class="input-group-text">이름</span>
        </div>
        <input
          type="text"
          placeholder="Username"
          v-model="input_name"
          class="form-control"
          required
          />
      </div>
      <div class="input-group mb-3 mt-3">
        <div class="input-group-prepend">
           <span class="input-group-text">나이</span>
        </div>
        <input
          type="text"
          placeholder="Userage"
          v-model="input_age"
          class="form-control"
          required
          maxLength="2"
          pattern="[0-9]{1,2}"
        >
      </div>
      <button type="submit" class="btn btn-info">{{state}}</button>
      <div class="error">{{error}}</div> 
    </form>

    <table class="table table-striped">
            <caption>
                <h3>name list</h3>
            </caption>
            <tr>
                <th>번호</th>
                <th>이름</th>
                <th>나이</th>
                <th>수정</th>
                <th>삭제</th>
            </tr>

            <tr v-for="(item, index) in list" :key="index">
                <td>{{item.id}}</td>
                <td>{{item.name}}</td>
                <td>{{item.age}}</td>
                <td><button class="btn btn-primary" @click="update(item)">수정</button></td>
                <td><button class="btn btn-danger" @click="del(item.id)">삭제</button></td>
            </tr>
    </table>
  </div>      

                   
</template>

<script>
import axios from 'axios';
import {ref} from 'vue'
export default{
    setup(){
        const list = ref([]);
        const error = ref('');
        const input_name=ref('');
        const input_age=ref(0);
        const state=ref("추가");
        let update_id = 0; //139번 라인에서 수정할 아이디값을 저장할 변수 입니다.

        const getList = async () =>{
            try{
                const res = await axios.get('http://localhost:8088/vue/users')
                list.value = res.data.list;
            } catch (err) {
                console.log(err);
                error.value = '리스트 가져오는 중 오류.';
            }
        };

        getList();
        
        const add = async () => {
            error.value = '';
            if(state.value=='추가'){
              try{
                  const res = await axios.post('http://localhost:8088/vue/users', {
                      name: input_name.value,
                      age: input_age.value,
                  });
                  getList;
              } catch (err) {
                  console.log(err);
                  error.value = '삽입 중 오류 발생';
              }
            }else{
              try {
                    await axios.patch('http://localhost:8088/vue/users', {
                      name: input_name.value,
                      age: input_age.value,
                      id: update_id       //140번 라인에서 저장된 수정할 아이디값을 사용합니다.
                    });
                    input_name.value='';
                    input_age.value='';
                    state.value='추가';
                    getList();
              } catch (err) {
                console.log(err);
                error.value = 'update 중 오류 발생';
              }
            }//else end

        };//add end

        const del = async (id)=>{
          let answer = confirm('정말 삭제하시겠습니까?');
          if(answer){
            try{
              await axios.delete(`http://localhost:8088/vue/users/${id}`);
              getList();
            }catch(err){
              console.log(err);
              error.value = '삭제 중 오류';
            }
          }//if end
        };






        //name list에서 수정 버튼 클릭시
        //이름과 나이 input에 선택한 이름과 나이가 나타나고
        //추가 버튼의 레이블을 수정완료로 변경합니다.
        const update = (item)=>{
          input_name.value = item.name;
          input_age.value = item.age;
          state.value='수정완료';
          update_id = item.id;  //105번라인에서 update_id의 값을 사용합니다.
        }

        return{
          list, error, add, input_name, input_age, update, state, del
        }      
    }
};
</script>

<style scoped>
   caption{caption-side: top; text-align: center}
   .error{color:red}
</style>
