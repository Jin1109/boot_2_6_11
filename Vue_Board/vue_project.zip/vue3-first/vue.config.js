/*
 * 1. 웹팩은 싱글 파일 컴포넌트(.vue)로 작성한 파일을 브라우저가 인식할 수있는 형태의 파일로 변환해 줍니다.
 * 
 * 2. cmd창에서 CD C:\vue_project\vue3-first에서 npm run build
 * 
 * 3. 브라우저에서 http://localhost:8088/vue 로 접속합니다.
 */
 
module.exports = {
  // 주의점 : 경로 지정시 "/"로 사용하세요
  //vue build시 build된 파일 경로
  outputDir: "C:/WORKSPACE/boot_2_6_11/Vue_Board/src/main/resources/static",

  //index.html 경로
  indexPath: "C:/WORKSPACE/boot_2_6_11/Vue_Board/src/main/resources/templates/index.html",

  //기본 시작 경로 - <link rel="icon" href=<%= BASE_URL %>icream.ico">의 <%= BASE_URL %>에 해당 값입니다.
  publicPath: "/vue/"

};